GitHub project homepage for the finite crystal theory.
See PKU page for official reference.